#include <GLFW/glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <cmath>


using namespace std;

const float DEG2RAD = 3.14159 / 180;
void processInput(GLFWwindow* window);

int score = 0;
int lives = 3;
bool gameRunning = true;  

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

// Particle Class
class Particle {
public:
    float x, y, vx, vy, lifetime;
    float red, green, blue;

    Particle(float xx, float yy) {
        x = xx;
        y = yy;
        lifetime = 1.0;
        float angle = (rand() % 360) * DEG2RAD;
        float speed = (rand() % 10) / 500.0;
        vx = cos(angle) * speed;
        vy = sin(angle) * speed;
        red = 1.0;
        green = ((rand() % 100) / 100.0);
        blue = ((rand() % 100) / 100.0);
    }

    void update() {
        x += vx;
        y += vy;
        lifetime -= 0.02;
    }

    void draw() {
        if (lifetime > 0) {
            glColor4f(red, green, blue, lifetime);
            glBegin(GL_QUADS);
            glVertex2f(x - 0.005, y - 0.005);
            glVertex2f(x + 0.005, y - 0.005);
            glVertex2f(x + 0.005, y + 0.005);
            glVertex2f(x - 0.005, y + 0.005);
            glEnd();
        }
    }
};

vector<Particle> particles;

void createParticles(float x, float y) {
    for (int i = 0; i < 10; i++) {
        particles.emplace_back(x, y);
    }
}

// Brick Class
class Brick {
public:
    float x, y, width, red, green, blue;
    BRICKTYPE brick_type;
    ONOFF onoff;
    int durability;

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float r, float g, float b, int dur) {
        brick_type = bt; x = xx; y = yy, width = ww;
        onoff = ON; red = r; green = g; blue = b;
        durability = dur;
    }

    void cycleColor() {
        static float colorShift = 0;
        colorShift += 0.5;
        red = sin(colorShift) * 0.5 + 0.5;
        green = sin(colorShift + 2) * 0.5 + 0.5;
        blue = sin(colorShift + 4) * 0.5 + 0.5;
    }
    void weaken() {
        durability -= 10;
        red = durability / 100.0;
        green = (100 - durability) / 100.0;
        blue = 0.5;
        if (durability <= 0) {
            onoff = OFF;
        }
        if (brick_type == REFLECTIVE) {
            red = 1.0; green = 1.0; blue = 1.0;
        }
    }
    void drawBrick() {
        if (onoff == ON) {
            double halfside = width / 2;
            glColor3f(red, green, blue);
            glBegin(GL_QUADS);
            glVertex2d(x + halfside, y + halfside);
            glVertex2d(x + halfside, y - halfside);
            glVertex2d(x - halfside, y - halfside);
            glVertex2d(x - halfside, y + halfside);
            glEnd();
        }
    }
};

// Ball Class
class Circle {
public:
    float x, y, radius, speed;
    int direction;
    float red, green, blue;

    Circle(float xx, float yy, float rr, int dir, float spd, float r, float g, float b) {
        x = xx; y = yy; radius = rr; speed = spd; direction = dir;
        red = r; green = g; blue = b;
    }

    void MoveOneStep() {
        // Bounce off the left and right walls
        if (x - radius <= -1.0) {
            x = -1.0 + radius;  // Prevent getting stuck
            direction = 180 - direction;
        }
        if (x + radius >= 1.0) {
            x = 1.0 - radius;
            direction = 180 - direction;
        }

        // Bounce off the top wall
        if (y + radius >= 1.0) {
            y = 1.0 - radius;
            direction = -direction;
        }

        // Check if the ball falls below the screen (missed by paddle)
        if (y - radius <= -1.0) {
            lives--;  // Decrease lives
            if (lives <= 0) {
                gameRunning = false;  // Stop game when lives reach 0
            }
            else {
                // Reset ball position after missing a paddle hit
                x = 0.0;
                y = -0.7;
                direction = 45;
            }
        }

        // Update ball position
        x += speed * cos(direction * DEG2RAD);
        y += speed * sin(direction * DEG2RAD);
    }

    void DrawCircle() {
        glColor3f(red, green, blue);
        glBegin(GL_POLYGON);
        for (int i = 0; i < 360; i++) {
            float degInRad = i * DEG2RAD;
            glVertex2f((cos(degInRad) * radius) + x, (sin(degInRad) * radius) + y);
        }
        glEnd();
    }

    void CheckPaddleCollision(Brick* paddle) {
        if (y - radius <= paddle->y + 0.05 && x >= paddle->x - paddle->width / 2 && x <= paddle->x + paddle->width / 2) {
            paddle->cycleColor();
            direction = 360 - direction;
            y = paddle->y + paddle->width / 2 + radius;
        }
    }

    void CheckBrickCollision(vector<Brick>& bricks) {
    for (Brick& b : bricks) {
        if (b.onoff == ON &&
            y + radius >= b.y - b.width / 2 &&
            y - radius <= b.y + b.width / 2 &&
            x >= b.x - b.width / 2 &&
            x <= b.x + b.width / 2) {
            
            b.weaken();
            createParticles(b.x, b.y);
            direction = -direction;

            // Increase score when hitting a brick
            score += 10;

            // If the brick is destroyed, add bonus points
            if (b.durability <= 0) {
                score += 20;
            }

            return;
        }
    }
}
};

// Particle System Updates
void updateParticles() {
    for (auto it = particles.begin(); it != particles.end();) {
        it->update();
        if (it->lifetime <= 0) {
            it = particles.erase(it);
        }
        else {
            ++it;
        }
    }
}

void drawParticles() {
    for (Particle& p : particles) {
        p.draw();
    }
}

// Game Objects
vector<Circle> world;
Brick* paddle;

void displayGameOver() {
    glClear(GL_COLOR_BUFFER_BIT); // Clear the screen

    // Set the background color to red
    glClearColor(1.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw a black "GAME OVER" rectangle in the middle
    glColor3f(0.0, 0.0, 0.0);
    glBegin(GL_QUADS);
    glVertex2f(-0.6, 0.2);
    glVertex2f(0.6, 0.2);
    glVertex2f(0.6, -0.2);
    glVertex2f(-0.6, -0.2);
    glEnd();

    // Set the text color to white
    glColor3f(1.0, 1.0, 1.0);

    // Update window title to "Game Over"
    glfwSetWindowTitle(glfwGetCurrentContext(), "GAME OVER! Press ESC to Exit");

    // Swap buffers to display the screen update
    glfwSwapBuffers(glfwGetCurrentContext());
}

void drawLives() {
    float startX = -0.9f;  // Position of the first life icon
    float y = 0.9f;        // Fixed height for life display

    for (int i = 0; i < lives; i++) {
        glColor3f(1.0, 0.0, 0.0); // Red color for life indicator
        glBegin(GL_POLYGON);
        for (int j = 0; j < 360; j++) {
            float degInRad = j * DEG2RAD;
            glVertex2f(startX + (cos(degInRad) * 0.03), y + (sin(degInRad) * 0.03));
        }
        glEnd();
        startX += 0.08; // Space out the life indicators
    }
}

int main(void) {
    vector<Brick> bricks;
    float pyramidStartY = 0.8;
    float brickWidth = 0.1;
    float spacing = 0.01;
    int pyramidRows = 10;
    float pyramidStartX = -((pyramidRows * (brickWidth + spacing)) / 2) + (brickWidth / 2) + 0.3;

    for (int row = 0; row < pyramidRows; row++) {
        int durability = 100 - (row * 10); // Set durability per row
        for (int col = 0; col < row + 1; col++) {
            float colorFactor = static_cast<float>(row) / pyramidRows;
            float r = sin(colorFactor * 3.14159 * 2) * 0.5 + 0.5;
            float g = sin((colorFactor + 0.33) * 3.14159 * 2) * 0.5 + 0.5;
            float b = sin((colorFactor + 0.66) * 3.14159 * 2) * 0.5 + 0.5;
            bricks.emplace_back(DESTRUCTABLE, pyramidStartX + (col * (brickWidth + spacing)) - (row * (brickWidth / 2)),
                pyramidStartY - (row * (brickWidth + spacing)), brickWidth, r, g, b, durability);
        }
    }

    srand(time(NULL));
    if (!glfwInit()) exit(EXIT_FAILURE);
    GLFWwindow* window = glfwCreateWindow(1920, 1080, "Brick Breaker", NULL, NULL);
    if (!window) { glfwTerminate(); exit(EXIT_FAILURE); }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    paddle = new Brick(REFLECTIVE, 0.0, -0.9, 0.2, 1.0, 0.0, 0.0, 100);
    Circle ball(0.0, -0.7, 0.03, 45, 0.02, 1.0, 1.0, 1.0);
    world.push_back(ball);

    while (!glfwWindowShouldClose(window)) {
        if (!gameRunning) {
            displayGameOver();
            glfwPollEvents();
            continue;
        }

        // Update window title with score and lives
        char title[50];
        sprintf_s(title, sizeof(title), "Brick Breaker | Score: %d | Lives: %d", score, lives);
        glfwSetWindowTitle(window, title);

        // Create a dynamic gradient effect using time
        float time = glfwGetTime();
        float red = (sin(time * 0.5) * 0.5) + 0.5;
        float green = (cos(time * 0.5) * 0.5) + 0.5;
        float blue = (sin(time * 0.3) * 0.5) + 0.5;

        glClearColor(red, green, blue, 1.0);
        glClear(GL_COLOR_BUFFER_BIT);

        drawLives();  // Draw remaining lives

        for (Brick& b : bricks) {
            b.drawBrick();
        }
        updateParticles();
        drawParticles();
        processInput(window);

        for (Circle& c : world) {
            c.MoveOneStep();
            c.CheckPaddleCollision(paddle);
            c.CheckBrickCollision(bricks);
            c.DrawCircle();
        }
        paddle->drawBrick();

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    exit(EXIT_SUCCESS);
}


void processInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // Check for Left Arrow Key
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS && paddle->x > -0.85) {
        paddle->x -= 0.05;  // Move left
    }

    // Check for Right Arrow Key
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS && paddle->x < 0.85) {
        paddle->x += 0.05;  // Move right
    }
}


